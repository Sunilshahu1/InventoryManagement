﻿using DomainLayer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceLayer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class OrderController : ControllerBase

    {
        private readonly IOrderService _serviceOrder;
        private readonly ILogger _logger;

        public OrderController(ILogger<OrderController> logger, IOrderService serviceOrder)
        {
            
            _serviceOrder = serviceOrder;
            _logger = logger;

        }

       

        [HttpPost(nameof(InsertOrders))]
        public async Task<IActionResult> InsertOrders(OrderTable model)
        {
            _logger.LogInformation("Start Order Insert..");
            var result = await _serviceOrder.Insert(model);
            if (result == true)
            {
                _logger.LogInformation("Succesfully Inserted Order");
                return Ok("Succesfully Order inserted");
            }

            else
            {
                _logger.LogWarning("Order Is Not Inserted..");
                return BadRequest("Order not inserted");
            }
        }
        [HttpDelete(nameof(DeleteOrder))]
        public async Task<IActionResult> DeleteOrder(Guid Id)
        {
            _logger.LogInformation("Start Order Deletion..");
            if (Id != Guid.Empty)
            {
                var result = await _serviceOrder.Delete(Id);
                if (result == true)
                {
                    _logger.LogInformation("Succesfully Delete Order");
                    return Ok("Order Deleted");
                }
                else
                {
                    _logger.LogWarning("Not Delete Order");
                    return BadRequest("Order Not Deleted");
                }

            }
            else
            {
                _logger.LogWarning("Invalid Order Id");
                return BadRequest("Invalid Order Id");
            }
        }


            [HttpPut(nameof(UpdateOrder))]
        public async Task<IActionResult> UpdateOrder(OrderTable orderUpdateModel)
        {


            _logger.LogInformation("Start Order Updation..");
            var result = await _serviceOrder.Update(orderUpdateModel);
            if (result == true) { 
                _logger.LogInformation("Update Order");
                return Ok("Order Information Updated");
            }
            else {
                _logger.LogWarning("Not Update Order");
                return BadRequest("Order Not Updated..");
            }

        }
        [HttpGet(nameof(GetOrder))]
        public async Task<ActionResult<OrderTable>> GetOrder(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                _logger.LogInformation("Get Order by Id");
                var result = await _serviceOrder.Get(Id);
                if (result == null)
                {
                    _logger.LogWarning("No records Found");
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                _logger.LogWarning("Invalid Order ID..");
                return NotFound("Invalid Order Id...");
            }
        }
        [HttpGet(nameof(GetAllOrders))]
        public async Task<ActionResult<OrderTable>> GetAllOrders()
        {
            _logger.LogInformation("Get All Orders");
            var result = await _serviceOrder.GetAll();
            if (result == null)
            {
                _logger.LogWarning("No Found Order");
                return BadRequest("No Records Found");
            }
            _logger.LogInformation("Successfull..");
            return Ok(result);
        }


        
    }
}
