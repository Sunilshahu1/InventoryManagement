﻿
using DomainLayer.Models;
using InventoryManagement.Models;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DomainLayer.ViewModel;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace InventoryManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class ItemController : ControllerBase
    {
        private readonly IItemService _serviceItem;
        private readonly ILogger _logger;

        public ItemController(ILogger<ItemController> logger,IItemService serviceItem)
        {
            _serviceItem = serviceItem;
            _logger = logger;
        }
        [Authorize]
        [HttpPost(nameof(InsertItem))]
        public async Task<IActionResult> InsertItem(Itemtable itemModel)
        {
            _logger.LogInformation("Start Item Insert..");
            //OrderTable orderes = await _serviceOrder.Find(x => x.Id == itemModel.UserId);
            var result = await _serviceItem.Insert(itemModel);
            if (result == true) { 
                _logger.LogInformation("Succesfully Inserted Item");
                  return Ok("Succesfully Item inserted");
            }
            else { 
                _logger.LogWarning("Item Is Not Inserted..");
                 return BadRequest("Item not inserted");
            }
        }
       
        [HttpDelete(nameof(DeleteItem))]
        public async Task<IActionResult> DeleteItem(Guid Id)
        {
            _logger.LogInformation("Start Item Deletion..");
            if (Id != Guid.Empty)
            {
                var result = await _serviceItem.Delete(Id);
                if (result == true) { 
                    _logger.LogInformation("Succesfully Delete  Item");
                     return Ok("Item Deleted");
                }
                else {
                    _logger.LogWarning("Not Delete Item");
                    return BadRequest("Item Not Deleted");
                }
            }
            else {
                _logger.LogWarning("Invalid Item Id");
                return BadRequest("Invalid Item Id");
            }

        }

        //[HttpGet(nameof(SearchByName))]
        //public IActionResult SearchByName(string name)
        //{

        //    var itemname = _serviceItem.SearchByName(name);
        //    if (itemname is not null)
        //    {
        //        _logger.LogInformation($"Get tblItem data by Name : {name}");
        //        return Ok(itemname);
        //    }
        //    _logger.LogError($"Get tblItem data by Name : {name}  is Not Fount");
        //    return BadRequest("Records Not found");
        //}

        [HttpPut(nameof(UpdateItem))]
        public async Task<IActionResult> UpdateItem(Itemtable itemUpdateModel)
        {


            _logger.LogInformation("Start Item Updation..");
            var result = await _serviceItem.Update(itemUpdateModel);
            if (result == true) {
                _logger.LogInformation("Update Item");
                return Ok("Item Information Updated");
            }
            else {
                _logger.LogWarning("Not Update Item");
                return BadRequest("Item Not Updated..");
            }


        }

        [HttpGet(nameof(GetAllItem))]
        public async Task<ActionResult<Itemtable>> GetAllItem()
        {
            _logger.LogInformation("Get All Items");
            var result = await _serviceItem.GetAll();
            if (result == null)
            {
                _logger.LogWarning("No Found Item");
                return BadRequest("No Records Found");
            }
            _logger.LogInformation("Successfull..");
            return Ok(result);
        }
        [HttpGet(nameof(GetItem))]
        public async Task<ActionResult<Itemtable>> GetItem(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                _logger.LogInformation("Get Item by Id");
                var result = await _serviceItem.Get(Id);
                if (result == null)
                {
                    _logger.LogWarning("No records Found");
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else { 
                _logger.LogWarning("Invalid Item ID..");
            return NotFound("Invalid Item Id...");
            }
        }
    }  
}
