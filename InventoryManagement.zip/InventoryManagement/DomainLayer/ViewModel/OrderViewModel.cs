﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModel
{
    public class OrderViewModel
    { 
          public Guid Id { get; set; }
    public string OrderId { get; set; }
    public int Quantity { get; set; }
    public DateTime OrderDate { get; set; }
    public decimal TotalAmount { get; set; }
    public Guid ItemId { get; set; }
        public List<ItemViewModel> Item { get; set; } = new List<ItemViewModel>();

    }
    public class OrderInsertModel
    {
        
        public string OrderId { get; set; }

       
        public int Quantity { get; set; }


        public DateTime OrderDate { get; set; }

        public decimal TotalAmount { get; set; }

       public Guid ItemId { get; set; }
       

        

    }
    public class OrderUpdateModel : OrderInsertModel
    {
       
        public Guid Id { get; set; }

    }
}
