﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModel
{
    public class ItemViewModel
    {
        public Guid ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public decimal ItemPrice { get; set; }
        public int OpeningStock { get; set; }
        public string MeasurmentUnit { get; set; }
        public int TotalStock { get; set; }
    }
    public class ItemInsertModel
    {

        public string ItemCode { get; set; }


        public string ItemName { get; set; }


        public string ItemDescription { get; set; }


        public decimal ItemPrice { get; set; }
        public int OpeningStock { get; set; }
        public string MeasurmentUnit { get; set; }
        public int TotalStock { get; set; }

    }
    public class ItemUpdateModel : ItemInsertModel
    {
        
        public Guid Id { get; set; }
    }
    public class OrderView
    {
        public Guid Id { get; set; }
        public string OrderId { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        public Guid ItemId { get; set; }
        
    }



}
