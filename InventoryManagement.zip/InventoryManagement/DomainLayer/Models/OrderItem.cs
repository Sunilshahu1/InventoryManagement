﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
   public class OrderItem :BaseEntity
    {
       
        public Guid ItemId { get; set; }
        public virtual Itemtable Item { get; set; }

       
        public Guid OrderId { get; set; }
        public virtual OrderTable Orders { get; set; }
    }
}
