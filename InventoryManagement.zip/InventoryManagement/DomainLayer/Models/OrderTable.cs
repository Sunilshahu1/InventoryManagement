﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class OrderTable : BaseEntity
    {
        [Required(ErrorMessage = "Please Enter Order Id")]
        public string OrderId { get; set; }
        [Required(ErrorMessage = "Please Enter Quantity")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "Please Enter correct Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime OrderDate { get; set; }
       [Required(ErrorMessage = "Please Enter Total Amount")]
        public decimal TotalAmount { get; set; }

        // public int oId { get; set; }
        [Required(ErrorMessage = "Please Enter Item Id")]
        public Guid ItemId { get; set; }
        [JsonIgnore]
        public virtual Itemtable items { get; set; }
       // public virtual List<Itemtable> Items { get; set; }
       [JsonIgnore]
        public virtual List<OrderItem> OrderItems { get; set; }
    }
}
