﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class Itemtable : BaseEntity
    {
        [Required(ErrorMessage = "Please Enter ItemCode")]
        [RegularExpression(@"(?:\s|^)#[A-Za-z0-9]+(?:\s|$)", ErrorMessage = "Item Code start with # and Only Number and character are allowed eg(#Item1001)")]
        [StringLength(10)]
        public string ItemCode { get; set; }

        [Required(ErrorMessage = "Please Enter Item Name")]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Item Name must be aplphabet.")]
        [StringLength(100)]
        public string ItemName { get; set; }

        [Required(ErrorMessage = "Please Enter Item Description")]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Item Description must be aplphabet.")]
        public string ItemDescription { get; set; }
        [Required(ErrorMessage = "Please Enter Item Price")]
        public decimal ItemPrice { get; set; }

        [Required(ErrorMessage = "Please Enter Opening Stock")]
        public int OpeningStock { get; set; }
        [Required(ErrorMessage = "Please Enter Measurement Unit.")]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Measurment Unit must be aplphabet.")]
        public string MeasurmentUnit { get; set; }
        [Required(ErrorMessage = "Please Enter Total Stock.")]
        public int TotalStock { get; set; }
        [JsonIgnore]
        public virtual List<OrderTable> Orders { get; set; }
        [JsonIgnore]
        public virtual List<OrderItem> OrderItem { get; set; }


    }
}
