﻿using DomainLayer.Models;
using RepositoryLayer.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class OrderService : IOrderService
    {
        private readonly IRepository<Itemtable> _item;
        private readonly IRepository<OrderTable> _ordeers;
        private readonly IRepository<OrderItem> _orderitems;

        public OrderService(IRepository<OrderTable> orders, IRepository<Itemtable> item, IRepository<OrderItem> orderitems)
        {
            _item = item;
            _ordeers = orders;
            //_orderService = orderService;
            _orderitems = orderitems;

        }
        public async Task<bool> Delete(Guid Id)
        {
           
                OrderTable order = await _ordeers.Get(Id);
                if (order != null)
                {

                    var orderItems = await _orderitems.FindAll(x => x.OrderId == order.Id);
                    foreach (var item in orderItems)
                    {
                        await _orderitems.Delete(item);
                    }

                  

                    if (await _ordeers.Delete(order))
                    {
                      
                        return true;
                    }
                    else
                    {
                    return false;
                    }
                }
                else
                {
                return false;
                }
           

        }
        

         public Task<OrderTable> Find(Expression<Func<OrderTable, bool>> match)
        {
            throw new NotImplementedException();
        }

        public async Task<OrderTable> Get(Guid Id)
        {
            var result = await _ordeers.Get(Id);
            return result;
        }

        public async Task<ICollection<OrderTable>> GetAll()
        {
            return await _ordeers.GetAll();
        }

        public async Task<bool> Insert(OrderTable orderInsertModel)
        {
            OrderTable ord = new OrderTable()
            {
                OrderId = orderInsertModel.OrderId,
                Quantity = orderInsertModel.Quantity,
                OrderDate = orderInsertModel.OrderDate,
                TotalAmount = orderInsertModel.TotalAmount,
                ItemId = orderInsertModel.ItemId,
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now

            };
            var result = await _ordeers.Insert(ord);
            if (result == true)
            {
                OrderItem orderItem = new OrderItem()
                {
                    ItemId = orderInsertModel.ItemId,
                    OrderId = ord.Id,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                    
                };
                await _orderitems.Insert(orderItem);
            }
            return true;
        }
        public async Task<bool> Update(OrderTable orderUpdateModel)
        {
            OrderTable ords = await _ordeers.Get(orderUpdateModel.Id);
            if (ords != null)
            {
                ords.OrderId = orderUpdateModel.OrderId;
                ords.OrderDate = orderUpdateModel.OrderDate;
                ords.Quantity = orderUpdateModel.Quantity;
                ords.TotalAmount = orderUpdateModel.TotalAmount;
                ords.ItemId = orderUpdateModel.ItemId;
                ords.CreatedDate = orderUpdateModel.CreatedDate;
                ords.ModifiedDate = DateTime.Now;



                var result = await _ordeers.Update(ords);
                return result;
            }
            else
            {
                return false;
            }
        }

        public async Task<ICollection<OrderTable>> FindAll(Expression<Func<OrderTable, bool>> match)
        {
            return await _ordeers.FindAll(match);
        }
    }
}
