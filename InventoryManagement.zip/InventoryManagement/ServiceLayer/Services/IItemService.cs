﻿using DomainLayer.Models;
using DomainLayer.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public interface IItemService
    {
        Task<ICollection<Itemtable>> GetAll();
       // Task<ICollection<Itemtable>> SearchByName(string name);
        //IEnumerable<Itemtable> SearchByName(string name);
        // Task<T> Get(Guid Id);
        Task<Itemtable> Get(Guid Id);
        Task<bool> Insert(Itemtable itemInsertModel);
        Task<bool> Update(Itemtable itemUpdateModel);
        Task<bool> Delete(Guid Id);
        Task<Itemtable> Find(Expression<Func<Itemtable, bool>> match);
        Task<ICollection<Itemtable>> FindAll(Expression<Func<Itemtable, bool>> match);

    }
}
