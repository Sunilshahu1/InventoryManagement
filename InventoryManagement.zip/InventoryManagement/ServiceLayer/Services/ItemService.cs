﻿using DomainLayer.Models;
using DomainLayer.ViewModel;
using RepositoryLayer.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class ItemService : IItemService
    {
        private readonly IRepository<Itemtable> _item;
        private readonly IRepository<OrderTable> _ordeer;

       // private readonly IOrderService _orderService;
       
        private readonly IRepository<OrderItem> _orderItem;

        public ItemService(IRepository<Itemtable> item, IRepository<OrderTable> ordeer, IRepository<OrderItem> orderItem)
        {
            _item = item;
            _ordeer = ordeer;
            //_orderService = orderService;
            _orderItem = orderItem;

        }
        public async Task<bool> Delete(Guid Id)
        {
            Itemtable items = await _item.Get(Id);
            if (items != null)
            {

                var orderItems = await _orderItem.FindAll(x => x.ItemId == items.Id);
                foreach (var item in orderItems)
                {
                    await _orderItem.Delete(item);
                }



                if (await _item.Delete(items))
                {

                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public Task<Itemtable> Find(Expression<Func<Itemtable, bool>> match)
        {
            throw new NotImplementedException();
        }

        public async Task<ICollection<Itemtable>> FindAll(Expression<Func<Itemtable, bool>> match)
        {
            return await _item.FindAll(match);
        }

        public async Task<Itemtable> Get(Guid Id)
        {
            var result = await _item.Get(Id);
            return result;
        }

        public async Task<ICollection<Itemtable>> GetAll()
        {
            return  await _item.GetAll();
        }

        public async Task<bool> Insert(Itemtable itemInsertModel)
        {
            Itemtable item1 = new Itemtable()
            {
                ItemCode = itemInsertModel.ItemCode,
                ItemName = itemInsertModel.ItemName,
                ItemDescription = itemInsertModel.ItemDescription,
                ItemPrice = itemInsertModel.ItemPrice,
               OpeningStock = itemInsertModel.OpeningStock,
                MeasurmentUnit = itemInsertModel.MeasurmentUnit,
                TotalStock = itemInsertModel.TotalStock,
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now

            };
            await _item.Insert(item1);
            return true;
        }

        //public async Task<ICollection<Itemtable>> SearchByName(string name)
        //{
        //    return await _item.SearchItem(x=> x.ItemName==name);
        //}

        public async Task<bool> Update(Itemtable itemUpdateModel)
        {
            Itemtable item = await _item.Get(itemUpdateModel.Id);
            if (item != null)
            {
                item.ItemCode = itemUpdateModel.ItemCode;
                item.ItemName = itemUpdateModel.ItemName;
                item.ItemDescription = itemUpdateModel.ItemDescription;
                item.OpeningStock = itemUpdateModel.OpeningStock;
                item.MeasurmentUnit = itemUpdateModel.MeasurmentUnit;
                item.TotalStock = itemUpdateModel.TotalStock;
                item.CreatedDate = itemUpdateModel.CreatedDate;
                item.ModifiedDate = DateTime.Now;
               
              

                var result = await _item.Update(item);
                return result;
            }
            else
            {
                return false;
            }
        }
    }
}
