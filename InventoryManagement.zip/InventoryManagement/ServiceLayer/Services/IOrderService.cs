﻿using DomainLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public interface IOrderService
    {
        /*Task<T> Get(Guid Id);*/
        Task<ICollection<OrderTable>> GetAll();
        Task<OrderTable> Get(Guid Id);
        Task<bool> Insert(OrderTable orderInsertModel);
        Task<bool> Update(OrderTable orderUpdateModel);
        Task<bool> Delete(Guid Id);
        Task<OrderTable> Find(Expression<Func<OrderTable, bool>> match);
        Task<ICollection<OrderTable>> FindAll(Expression<Func<OrderTable, bool>> match);
    }
}
