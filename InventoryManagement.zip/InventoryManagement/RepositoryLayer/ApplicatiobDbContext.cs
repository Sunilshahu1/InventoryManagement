﻿using DomainLayer.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer
{
   public class ApplicatiobDbContext : IdentityDbContext<ApplicationUser>
    {
        public DbSet<Itemtable> Items { get; set; }
        public DbSet<OrderTable> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
       

        public ApplicatiobDbContext(DbContextOptions<ApplicatiobDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<OrderTable>()
           .HasOne(b => b.items)
           .WithMany(b => b.Orders)
           .HasForeignKey(s => s.ItemId)
          .OnDelete(DeleteBehavior.NoAction)
           .IsRequired();

            modelBuilder.Entity<OrderItem>()
           .HasOne(b => b.Item)
           .WithMany(b => b.OrderItem)
           .HasForeignKey(s => s.ItemId)
            .OnDelete(DeleteBehavior.NoAction)
           .IsRequired();

            modelBuilder.Entity<OrderItem>()
           .HasOne(b => b.Orders)
           .WithMany(b => b.OrderItems)
           .HasForeignKey(s => s.OrderId)
            .OnDelete(DeleteBehavior.NoAction)
           .IsRequired();
        }
        }
}
